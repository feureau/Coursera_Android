package course.examples.Graphics.BubbleProgramXML;

import android.app.Activity;
import android.os.Bundle;
import course.examples.Graphics.Bubble.R;

public class BubbleActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
}